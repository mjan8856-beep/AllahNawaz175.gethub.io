import { projects } from "@/components/projects";

export default function CaseStudy({ params }: any) {
  const project = projects.find(p => p.slug === params.slug);
  if (!project) return <div>Not found</div>;

  return (
    <main>
      <h1>{project.title}</h1>
      <p>{project.desc}</p>
    </main>
  );
}