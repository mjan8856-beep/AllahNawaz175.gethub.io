export const metadata = {
  title: "Allah Nawaz – UI UX Designer | Product & SaaS Expert",
  description:
    "Allah Nawaz is a professional UI/UX Designer specializing in SaaS, product, and e-commerce experiences.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}