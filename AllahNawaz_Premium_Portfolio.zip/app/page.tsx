"use client";
import ProjectCard from "@/components/ProjectCard";
import { projects } from "@/components/projects";
import "./globals.css";

export default function Home() {
  return (
    <main>
      <section className="hero">
        <h1>Allah Nawaz</h1>
        <p>UI/UX Designer · Product · SaaS · E-commerce</p>
      </section>

      <section className="projects">
        <h2>Top Ranked Projects</h2>
        <div className="grid">
          {projects.map((p) => (
            <ProjectCard key={p.slug} {...p} />
          ))}
        </div>
      </section>

      <footer>© 2026 Allah Nawaz</footer>
    </main>
  );
}