export default function ProjectCard({ title, image, desc, badge }: any) {
  return (
    <div className="card">
      <img src={image} alt={title} />
      <h3>{title}</h3>
      <p>{desc}</p>
      <span>{badge}</span>
    </div>
  );
}