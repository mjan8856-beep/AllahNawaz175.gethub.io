export const projects = [
  {
    title: "Smarter Influencer Marketing with AI",
    slug: "ai-influencer-platform",
    image: "/ai.jpg",
    badge: "Top Project",
    desc: "AI-powered SaaS dashboard with data-driven UX."
  },
  {
    title: "ClickSy – Empowering Platform",
    slug: "clicksy-platform",
    image: "/clicksy.jpg",
    badge: "Top Project",
    desc: "Scalable platform UI with modern SaaS layout."
  }
];